const cartReducer = (state=[],action)=> {

    switch(action.type) {
        case 'add-to-cart':
                   
            const check = state.find(pr=> pr.id === action.food.id);     
               if(check){
                   alert("This food is alredy in the cart")
                   return state;
               }else{
                return [...state,{...action.food, qty: 1}] ;
               }
             //return [...state,{...action.food, qty: 1}] ;
          
        case 'remove-from-cart':
            const newItems=[]
            
            for (const food of state) {
                if(food.id !==action.food.id){
                    newItems.push(food)
                }
            }
            return newItems

        default:
            return state
    }

}

export default cartReducer
// const item =state.food.find((food)=>food.id===action.food.id);

// const inCart = state.food.find((item)=>
// item.id===action.food.id?true:false);
 // if(state.length!==0){
            //     const item =state.food.find((food)=>food.id===action.food.id);
            //     const inCart = state.food.find((item)=>
            //     item.id===action.food.id?true:false);
       
            // return{
            //     ...state,food: inCart ?
            //     state.food.map((item)=>
            //     item.id===action.food.id?
            //     {...item,qty:item.qty+1}:item)
            //     :[...state.food,{...item,qty:1}],
            // };

            
                // return 