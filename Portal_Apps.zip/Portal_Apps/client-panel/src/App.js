
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Home from './Components/Pages/Home';
import Category from './Components/Pages/Category';
import FoodData from './Components/Pages/FoodData';
import CategoryData from './Components/Pages/CategoryData';
import Cart from './Components/Cart/Cart';
import Signup from './Components/Pages/Signup';
import SearchResult from './Components/FoodContainers/SearchResult';
import PlaceOrder from './Components/Cart/PlaceOrder';
import AddressData from './Components/Cart/AddressData';
import ConfirmOrder from './Components/Cart/ConfirmOrder';
import ThankYou from './Components/Cart/ThankYou';
import Orders from './Components/User/Orders';
import OrdersData from './Components/User/OrdersData';


function App() {
  return (
    <BrowserRouter>
    <div className="App">
    <Navbar/>


    <div className="MainBox">
    <Switch>
      <Route exact path='/category' ><Category/></Route> 
      <Route exact path='/orderplaced' ><ThankYou/></Route> 
      <Route exact path='/place-order' ><PlaceOrder/></Route> 
      <Route exact path='/confirmorder/:orderId' ><ConfirmOrder/></Route> 
      <Route exact path='/address-data/:amount' ><AddressData/></Route> 
      <Route exact path='/category/:id' > <CategoryData/> </Route> 
      <Route exact path='/food/:id' ><FoodData/></Route> 
      <Route exact path='/search/:name' ><SearchResult/></Route> 
      <Route exact path='/cart' ><Cart/></Route> 
      <Route exact path='/signup' ><Signup/></Route> 
      <Route exact path='/home' render={()=><Home/>}  />
      <Route exact path='/ordersdata' ><OrdersData/></Route>
    </Switch>
  
    </div>
   
    
      </div>


      
    </BrowserRouter>
   
  );
}

export default App;
