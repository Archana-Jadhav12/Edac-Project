import React, { useEffect, useState } from 'react'
import { Card, Paper, CardContent, Typography,  CardMedia,  Button, CardActions } from '@material-ui/core';
import { useStyle1 } from './ContainerStyle';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { addToCartAction } from './../../Actions/CartActions';
import { useParams } from 'react-router';

export default function SearchResult() {
    const classes= useStyle1()
    const [foods , SetFoods]= useState([])
    const url="http://localhost:8080/"
    const {name}= useParams()
    const  dispatch = useDispatch()
    const  addToCart=(food)=>{
       // {...food,qty:1}
       dispatch(addToCartAction(food))
    }
    useEffect(() => {
        getSearchData()
    }, [])

    function getSearchData()
    {
        axios.get(url+"/food/search/"+name).then((response)=>{
          const result = response.data
          console.log(result)
          if(result.status==="success"){
            SetFoods(result.data)
          }else{
              alert("No data found")
          }
        })
    }
    
    return (
        <div>
            
            <div>
            <Typography align="center"  variant="h2">
                      Search Results
                        </Typography>
                        <hr/>
            </div>
                   {foods.map((food)=>( 
                     <div>
                    <Paper elevation="15" className={classes.vrContainer}>
                  <Card className={classes.root}>
                  <CardMedia
                        className={classes.cover}   
                        alt="Food Image"                    
                        image={url+food.image}
                        title="Live from space album cover"
                    />
                    <div className={classes.details}>
                        <CardContent className={classes.content}>
                        <Typography component="h5" color="textSecondary" variant="h3">
                        {food.foodName}
                        </Typography>
                        <Typography align="left" color="textSecondary" variant="h5">
                           Type: {food.type}
                        </Typography>
                        <Typography align="left" color="textSecondary" variant="h5">
                           Category: {food.catName}
                        </Typography>
                        <Typography align="left" color="textSecondary" variant="h6">
                           Description: {food.description}
                        </Typography>
                        </CardContent>
                        <div className={classes.controls}>
                        <CardActions>
                      
                        <Button className={classes.addButton2} onClick={()=>{addToCart(food)}} color="inherit">
                            Add
                        </Button >
                        <Typography variant="h4" align="right" color="textSecondary">
                            ₹ : {food.price}
                        </Typography>
                     </CardActions>
                        </div>
                    </div>
                  </Card> 
           </Paper>
           <br/>
           <hr/>
           <br/>
           </div>

                ))}
            
        </div>
    )
}
