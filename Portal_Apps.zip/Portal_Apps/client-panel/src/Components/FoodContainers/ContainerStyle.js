import { makeStyles } from '@material-ui/core';


export const useStyle1 = makeStyles((theme)=>({

itemContainer:{
    margin:'15px',
    minWidth: 320,
    maxWidth: 320,
    textDecoration:"None",    
},
catContainer:{
    float:'flex',
   display:'inline-block'
},
hztitle:{
    color:"White",
    textDecoration:"None",
},

vrContainer:{
    color:"White",
    padding:10,
    marginRight:400,
    marginLeft:500,
    backgroundColor:"rgb(1,1,1,0.5)",
   
  
},
foodImageCon:{
  height:450,
  width:550,
  borderRadius:20,
},

foodDataCon:{
  padding:30,
  backgroundColor:"White",
  opacity:0.9,
  color:"Grey", 
  borderRadius:10,
},

HzContainer:{ 
   padding:10,
    marginRight:200,
    marginLeft:200,
    backgroundColor:"rgb(1,1,1,0.5)",
},

scrollDiv:{
    display: 'flex',
    overflowX:'scroll'
},
card: {

    margin:'15px',
    color:"Black",
    maxWidth: 320,
    minWidth:320
},


addButton:{
    
    marginRight:125,
    backgroundColor:"Green",
    marginLeft:25
},
addButton2:{
    height:"40px",
    width:100,
    marginRight:200,
    backgroundColor:"Green",
    marginLeft:25
},
root: {
    display: 'flex',
    minWidth:900,
    minHeight:350,
    maxWidth:500
  },
  details: {
    display: 'flex',
    flexDirection: 'column',
  },
  content: {
    flex: '1 0 auto',
  },
  cover: {
    minWidth: 400,
  },
  controls: {
    display: 'flex',
    alignItems: 'center',
    paddingLeft: theme.spacing(1),
    paddingBottom: theme.spacing(1),
  },
  





}))