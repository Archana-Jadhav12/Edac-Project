import React, { useEffect, useState } from 'react'
import { CardActionArea, CardMedia, Paper, Typography, CardActions, Button, Card, CardContent, Box } from '@material-ui/core'
import axios from 'axios';
import {  useStyle1 } from './ContainerStyle';
import { NavLink } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCartAction } from './../../Actions/CartActions';




//send A category to listb food in horizontal pannel
export default function HorizontalCon({id}) {
    const classes= useStyle1()
    const [category , SetCategory]= useState([])
    const [foods , SetFoods]= useState([])
    const url="http://localhost:8080/"

    const  dispatch = useDispatch()
    const  addToCart=(food)=>{
       // {...food,qty:1}
       dispatch(addToCartAction(food))
    }


    useEffect(() => {
        getCategory()
    }, [])
       

    function getCategory()
    {
        axios.get(url+"/food/category/"+id).then((response)=>{
          const result = response.data
          if(result.status==="success"){
            SetCategory(result.data)
            SetFoods(result.data.foodList)
          }else{
              alert("No data found")
          }
        })
    }
 



    return (
        <div>
           <Paper elevation="15" className={classes.HzContainer}>
           <Typography variant="h3" className={classes.hztitle} 
           component={NavLink} to={'/category/'+category.id} >{category.categoryName} </Typography>
                <Box className={classes.scrollDiv}>
                    {foods.map((food)=>(  
                        <Card className={classes.itemContainer}  >
                            <CardActionArea component={NavLink} to={'/food/'+food.id}>
                            <CardMedia
                            component="img"
                            alt="Food Image"
                            height="200"
                            src= {url+food.image}
                            title="Food Image"
                            />
                            <CardContent>
                            <Typography variant="h5"  align="left"color="textSecondary">
                            {food.foodName}
                            </Typography>
                            <Typography variant="h6" align="left" color="textSecondary" component="p">
                            {food.catName}
                            </Typography>
                            <Typography variant="h6" align="left" color="textSecondary" component="p">
                            {food.type}
                            </Typography>
                            <Typography variant="body2"align="left" color="textSecondary" component="p">
                            {food.description}
                            </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions>
                        <Button className={classes.addButton} onClick={()=>{addToCart(food)}} size="small" color="inherit">
                            Add
                        </Button >
                            <Typography variant="h5" align="right" color="textSecondary">
                            ₹ : {food.price}
                            </Typography>
                    
                        </CardActions>
                    </Card>
                ))}
    </Box>
           </Paper>
        </div>
    )
}
