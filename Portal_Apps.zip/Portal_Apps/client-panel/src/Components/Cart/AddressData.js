import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography'
import Container from '@material-ui/core/Container';
import  Paper  from '@material-ui/core/Paper';
import { cartstyle } from './cartStyle';
import { Menu, MenuItem } from '@material-ui/core';
import Cookies from 'universal-cookie/es6';
import { useParams } from 'react-router';
import axios from 'axios';
import { useHistory } from "react-router-dom";
import { useSelector } from 'react-redux';





export default function AddressData() {
    const cookie = new Cookies();
    const history =useHistory();
    const {amount} = useParams()
    const firstName = cookie.get("name")
    const lastName = cookie.get("lastName")
    const userID = cookie.get("id")
    const classes = cartstyle();
    const [anchorEl, setAnchorEl] = useState(null);
    const [address, setAddress] = useState()
    const [phone, setPhone] = useState()
    const [payment, setPayment] = useState()
    const [comment, setComment] = useState()
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
      };
      const handleClose = () => {
        setAnchorEl(null);
      };

      const setCod=()=>{
        setPayment("COD")
    }
    const setUpi=()=>{
        setPayment("UPI")
    }
        const setDebit=()=>{
            setPayment("Card")
  }

      function CreateOrder(e){
        e.preventDefault();
        const data = new FormData()
        data.append("userId", userID)
        data.append("dAddress", address)
        data.append("phone", phone)
        data.append("totalAmount", amount)
        data.append("comment", comment)
        data.append("paymentType", payment)
        axios.post('http://localhost:8080/add-order',data).then((response)=>{
                const result = response.data
                console.log(result)
                    if(result.status==="success"){
                        const oID = result.data.id
                       
                      history.push("/confirmorder/"+oID);
                  }else{
                      alert("something went wrong")
                    }
               })
      }




    return (<div>

<br/>
        <div className="container">
        <Paper style={{width:600,alignItems:'center',marginLeft:200}}>
        <Container component="main" maxWidth="xs">
            <CssBaseline />
                    <div className={classes.paper}>
                    <br/>
                        <Typography component="h1" style={{color:"Black"}} variant="h5">
                     Order Details
                        </Typography>
                        <br/>
                        <form className={classes.form} noValidate>
                        <Grid container spacing={2}>
                            <Grid item xs={10} sm={10}>
                             <Typography component="h1" style={{color:"Black"}} variant="h5">
                              {"Name: "+firstName +" " +lastName}
                            </Typography>
                            </Grid>
                            <Grid item xs={12}>
                            <TextField
                                variant="outlined"
                                required
                                fullWidth
                                label="Delivery Address"
                               onChange={(e) => {
                                        setAddress(e.target.value)
                                      }} 
                            />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField
                                    variant="outlined"
                                    required
                                    fullWidth
                                    label="Phone"
                                    type="number"
                                    maxWidth="10"
                                    onChange={(e) => {
                                        setPhone(e.target.value)
                                      }} 
                                />
                            </Grid>
                            <Grid item xs={12}>
                            <TextField
                                variant="outlined"
                                required
                                fullWidth
                                label="Comment"
            
                                onChange={(e) => {
                                    setComment(e.target.value)
                                  }} 
                            />
                            </Grid>
                            <Grid container spacing={2} item xs={5}>
                             <Button color="primary" variant="outlined"  onClick={handleClick}>
                                    <Typography component="h1" style={{color:"Black"}} >
                                    Payment mode
                                    </Typography>
                                    </Button>
                                    <Menu
                                    
                                    id="simple-menu"
                                    anchorEl={anchorEl}
                                    keepMounted
                                    open={Boolean(anchorEl)}
                                    onClose={handleClose}
                                    >
                                    <MenuItem onClick={handleClose}> <Button style={{color:"Black"}}  onClick={setUpi}> 
                                    <Typography component="h1" style={{color:"Black"}} >
                                    UPI
                                    </Typography> 
                                    </Button></MenuItem>
                                    <MenuItem onClick={handleClose }><Button  style={{color:"Black"}}  onClick={setDebit}>
                                            <Typography component="h1" style={{color:"Black"}} >
                                    Debit Card
                                    </Typography> </Button></MenuItem>
                                    <MenuItem onClick={handleClose} ><Button style={{color:"Black"}}  onClick={setCod}>  
                                    <Typography component="h1" style={{color:"Black"}} >
                                    Cash On Delevery
                                    </Typography> </Button></MenuItem>
                                    </Menu>
                            </Grid>
                        </Grid>
                        <br/>
                        <br/>
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            color="primary"
                            onClick={CreateOrder}
                        >
                         place order
                        </Button>
                        </form>
                    </div>
            <Box mt={5}>
            </Box>
            </Container>
                <br/>
                </Paper>
                    </div>

    </div>
    )
}
