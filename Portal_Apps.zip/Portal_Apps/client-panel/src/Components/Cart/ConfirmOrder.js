import { Button, Typography } from '@material-ui/core'
import axios from 'axios'
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useParams } from 'react-router'
import { NavLink } from 'react-router-dom'
import { removeFromCartAction } from '../../Actions/CartActions'

export default function ConfirmOrder() {
 
  const cartItems = useSelector((state) => state.cartItems)

  const dispatch = useDispatch()

  const Oid = useParams("orderId")
  console.log(Oid.orderId)
    function AddItems(){
   

        for( const item of cartItems){
            const data = new FormData()
            data.append("catId", item.catId )
            data.append("foodName",item.foodName)
            data.append("foodId", item.id )
            data.append("orderId",Oid.orderId)
            data.append("price", item.price )
            data.append("unitQuanity",item.qty)
    
            axios.post('http://localhost:8080/add-item',data).then((response)=>{
                const result = response.data
                    if(result.status==="success"){
                        console.log("item Added")
                  }else{
                      alert("Wrong password")
                    }
               })
            dispatch(removeFromCartAction(item))
        }
    
        
    }
    

    return (
        <div>
            <br/>
            <br/>
           <br/>
                                <Typography variant="h2" align='center' > Your Order is ready  </Typography>
                                <br/>
                                <Typography variant="h5" align='center' > please click on Confirm to place your order</Typography>
                        <hr/>


                        <Button size='Large' style={{backgroundColor:"Green"}} onClick={AddItems} component={NavLink} to={"/orderplaced"} >
                                    Confirm Order</Button>
        </div>
    )
}
