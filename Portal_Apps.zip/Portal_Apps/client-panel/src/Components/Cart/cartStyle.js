import { makeStyles } from '@material-ui/core';


export const cartstyle = makeStyles((theme)=>({
    tableImg: {
       width:"200px",
        height:"200px"
      },
      
    tableCon: {
        marginLeft:150,
        marginRight:150,
        Width: 1000,
       
      },
      checkout: {

        Width: "100px",
        marginLeft:250,
        marginRight:250,
       
      },
    table: {
        minWidth: 700,
       
      },

}))