import {Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@material-ui/core';
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { NavLink } from 'react-router-dom';
import Cookies from 'universal-cookie/es6';
import Signin from '../Pages/Signin';
import { cartstyle } from './cartStyle';
const TAX_RATE = 0.13;


export default function PlaceOrder() {
    
    const cartItems = useSelector((state) => state.cartItems)
    const dispatch = useDispatch()
    const classes = cartstyle();

    let bill = 0
    cartItems.map((item)=> ( 
    bill = bill+item.qty * item.price
    ));
    console.log(bill)
    const tax = bill* TAX_RATE
    const totalBill = bill + tax 
    const cookie = new Cookies();
    const loggedin =cookie.get('name')


    if(loggedin){
      return (
        <div className={classes.tableCon}>
            <br/>
            <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="spanning table">
        <TableHead>
          <TableRow>
            <TableCell align="center" colSpan={3}>
                <Typography variant="h5" color="inherit"> Details</Typography>
              
            </TableCell>
            <TableCell align="right">
            <Typography variant="h5" color="inherit"> Sum </Typography>
            </TableCell>
          </TableRow>
          <TableRow>
            <TableCell><Typography variant="h6" color="inherit">Item Name</Typography></TableCell>
            <TableCell align="right"><Typography variant="h6" color="inherit">QTY.</Typography></TableCell>
            <TableCell align="right"><Typography variant="h6" color="inherit">Unit Price</Typography></TableCell>
            <TableCell align="right"><Typography variant="h6" color="inherit">Sum</Typography></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {cartItems.map((item) => (
            <TableRow key={item.foodName}>
              <TableCell>{item.foodName}</TableCell>
              <TableCell align="right"> {item.qty}</TableCell>
              <TableCell align="right">{item.price}</TableCell>
              <TableCell align="right">{item.qty * item.price}</TableCell>
            </TableRow>
          ))}

          <TableRow>
            <TableCell rowSpan={3} />
            <TableCell colSpan={2}><Typography variant="h6" color="inherit">Subtotal</Typography></TableCell>
            <TableCell align="right"><Typography variant="h6" color="inherit">{bill}</Typography>  </TableCell>
          </TableRow>
          <TableRow>
            <TableCell><Typography variant="h6" color="inherit">GST.</Typography></TableCell>
            <TableCell align="right"><Typography variant="h6" color="inherit">{`${(TAX_RATE * 100).toFixed(0)} %`}</Typography></TableCell>
            <TableCell align="right">
            <Typography variant="h6" color="inherit"> {ccyFormat(tax)}</Typography> 
                </TableCell>
          </TableRow>
          <TableRow>
            <TableCell colSpan={2}><Typography variant="h6" color="inherit">Total</Typography></TableCell>
            <TableCell align="right"><Typography variant="h6" color="inherit">{ccyFormat(bill + tax)}</Typography></TableCell>
          </TableRow>
          <TableRow>
          <TableCell  colSpan={4} align="right"  >
          <Button variant="contained" color="success"> 
          <Typography align="right"  variant="h6" color="primary" component={NavLink} to={"/address-data/"+totalBill}> Proceed </Typography> 
          </Button>
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
        </div>
    )

    }else{
      return ( <div>
              <br/>
                        <div>
                        <br/>
                                <Typography variant="h2" align='center' > You Are Not Logged In </Typography>
                                <br/>
                                <Typography variant="h5" align='center' > To log in click on the button bellow </Typography>
                        <hr/>
                        </div>
                        <br/>
                 <Signin/>
          </div>
      
      )
    }

    
}


function ccyFormat(num) {
    return `${num.toFixed(2)}`;
  }





