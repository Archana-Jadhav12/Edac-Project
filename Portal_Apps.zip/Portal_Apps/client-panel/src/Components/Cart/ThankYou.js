import { Typography } from '@material-ui/core'
import React from 'react'

export default function ThankYou() {
    return (
        <div>
              <div>
            <br/>
            <br/>
           <br/>
                                <Typography variant="h2" align='center' > Your Order Is Placed  </Typography>
                                <br/>
                                <Typography variant="h5" align='center' > we recived your order  </Typography>
                                <Typography variant="h5" align='center' >  it will be ready in 20 mins and dilevered to you in 30 minuts </Typography>
                        <hr/>


                      
        </div>
        </div>
    )
}
