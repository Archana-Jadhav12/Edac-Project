import { Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, withStyles } from '@material-ui/core'
import React, { useEffect, useState } from 'react'
import { useHistory } from "react-router-dom";
import { cartstyle } from './cartStyle';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCartAction } from '../../Actions/CartActions';
import { NavLink } from 'react-router-dom';

const StyledTableCell = withStyles((theme) => ({
    head: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
      fontSize: 25,
    },
    body: {
      fontSize: 25,
    },
  }))(TableCell);

  const StyledTableRow = withStyles((theme) => ({
    root: {
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
      },
    },
  }))(TableRow);
  /////////////////////////////////////////////////////////////////////////////////remove history 

export default function Cart() {
  const history = useHistory()
  const  cartItems = useSelector((state) => state.cartItems)
   
    const dispatch = useDispatch()
    const url="http://localhost:8080/"
    
    const classes = cartstyle();
    const removeFromCart=(food)=>{
        dispatch(removeFromCartAction(food))
    }
    

if(cartItems.length === 0){
    return(
    <div>
             <br/>
            <br/>
        <Typography variant="h2" align='center' > Sorry!!  Your Cart Is Empty </Typography>
        <br/>
        <Typography variant="h5" align='center' >Add Items to cart </Typography>
<hr/>
</div>
    )
}else{

    return (
        <div>
            
            <Typography variant="h3" align='center' >CART</Typography>
            <hr/>
            <br/>
                <Paper elevation={15} className={classes.tableCon} >

                <TableContainer  >
                                <Table className={classes.table} aria-label="customized table">
                                <TableHead>
                                        <TableRow>
                                            <StyledTableCell>Image</StyledTableCell>
                                            <StyledTableCell align="right">Food Name</StyledTableCell>
                                            <StyledTableCell align="right">Type</StyledTableCell>
                                            <StyledTableCell align="right">Price</StyledTableCell>
                                            <StyledTableCell align="right">Quantity</StyledTableCell>
                                            <StyledTableCell align="right">Action</StyledTableCell>
                        </TableRow>
                        </TableHead>
                        <TableBody>
                        {cartItems.map((food)=>(
                            <StyledTableRow >
                            <StyledTableCell component="th" scope="row">
                                <img src={url+food.image} className={classes.tableImg} />
                            </StyledTableCell>
                            <StyledTableCell align="right">{food.foodName}</StyledTableCell>
                            <StyledTableCell align="right">{food.type}</StyledTableCell>
                            <StyledTableCell align="right">{food.price}</StyledTableCell>
                            <StyledTableCell align="right">{food.qty}</StyledTableCell>
                            <StyledTableCell align="right">
                                
                                <Button style={{backgroundColor:"Red"}}
                                onClick={()=>{removeFromCart(food)}}>
                                    Remove</Button>
                            </StyledTableCell>
                            </StyledTableRow>

                        ))}
                            
                        
                        </TableBody>
                    </Table>
                    </TableContainer>

                </Paper>
                 <br/>    
                 <hr/>
                 <Button size='Large' style={{backgroundColor:"Green"}} component={NavLink} to={"/place-order"} >
                                    Check Out</Button>
                                    <br/>
                                    <br/> 
        </div>
    )}
}
