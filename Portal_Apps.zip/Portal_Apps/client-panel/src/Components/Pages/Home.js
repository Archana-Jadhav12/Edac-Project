import React from 'react'
import HorizontalCon from '../FoodContainers/HorizontalCon'

export default function Home() {
    return (
        <div>
           <HorizontalCon id={1}/> 
           <br/>
           <HorizontalCon id={2}/>
           <br/>
           <HorizontalCon id={3}/> 
        
        </div>
    )
}
