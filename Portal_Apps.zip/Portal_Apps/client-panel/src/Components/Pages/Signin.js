
import React, { useState } from 'react'
import { Box,  Avatar, Button, Typography } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Container from '@material-ui/core/Container';
import { useStyle } from '../Navbar/NavbarStyle';
import Cookies from 'universal-cookie';
import axios from 'axios';



export default function Signin(e) {
    const [open, setOpen] =useState(false);

    
    const classes = useStyle();
    const [email, setEmail] = useState()
    const [password, setPassword] = useState()
    const cookie = new Cookies();


    const handleClickOpen = () => {
        setOpen(true);
      };
    
      const handleClose1 = () => {
        setOpen(false);
      };

      

      function Authenticate(e){
        e.preventDefault();
        const data = new FormData()
        data.append("email", email)
        data.append("password", password)
       
        
       
                axios.post('http://localhost:8080/user/auth',data).then((response)=>{
                const result = response.data
                console.log(result)
                    if(result.status==="success"){
                        cookie.set("name", result.data.firstName,{ path: '/' },{maxAge :10})
                        cookie.set("lastName", result.data.lastName,{ path: '/' },{maxAge :10})
                        cookie.set("id", result.data.id,{ path: '/' },{maxAge :10})
                        window.location.assign("http://localhost:3001/home")
                  }else{
                      alert("Wrong password")
                    }
               })
       
        }












    return (
        <div>
                    <Box>
                    <div>
                    <Button variant="outlined" color="primary" onClick={handleClickOpen}>
                        Log-in
                    </Button>
                    <div>
                        <Dialog
                            open={open}
                            onClose={handleClose1}
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                        >
                           
                           <Container style={{width:900 }} component="main" maxWidth="xs">
                            <CssBaseline />
                            <div className={classes.paper}>
                                <Avatar className={classes.avatar}>
                                <LockOutlinedIcon />
                                </Avatar>
                                <Typography component="h1" variant="h5">
                                Sign in
                                </Typography>
                                <form className={classes.form} noValidate>
                                <TextField
                                    variant="outlined"
                                    margin="normal"
                                    required
                                    fullWidth
                                    id="email"
                                    label="Email Address"
                                    name="email"
                                    autoComplete="email"
                                    onChange={(e) => {
                                        setEmail(e.target.value)
                                      }} 
                                    autoFocus
                                />
                                <TextField
                                    variant="outlined"
                                    margin="normal"
                                    required
                                    fullWidth
                                    name="password"
                                    label="Password"
                                    type="password"
                                    id="password"
                                    onChange={(e) => {
                                        setPassword(e.target.value)
                                      }} 
                                    autoComplete="current-password"
                                />
                                <FormControlLabel
                                    control={<Checkbox value="remember" color="primary" />}
                                    label="Remember me"
                                />
                                <Button
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="primary"
                                    className={classes.submit}
                                    onClick={Authenticate}
                                >
                                    Sign In
                                </Button>
                                <Grid container>
                                    <Grid item xs>
                                    </Grid>
                                    <Grid item>
                                    <Link href="/signup" variant="body2">
                                        {"Don't have an account? Sign Up"}
                                    </Link>
                                    </Grid>
                                </Grid>
                                </form>
                            </div>
                            <Box mt={8}>
                            </Box>
                            </Container>
                    </Dialog>
                     </div>
                    </div>
            </Box>
            
        </div>
    )
}
