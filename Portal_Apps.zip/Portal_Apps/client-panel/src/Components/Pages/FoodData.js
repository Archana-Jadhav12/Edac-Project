import { Button, CardMedia, Paper, Typography } from '@material-ui/core'
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import HorizontalCon from '../FoodContainers/HorizontalCon';
import { useStyle1 } from './../FoodContainers/ContainerStyle';
import { useParams } from 'react-router';
import { useDispatch } from 'react-redux';
import { addToCartAction } from './../../Actions/CartActions';


export default function FoodData() {

    const [food , SetFood]= useState([])
    const {id}= useParams()

    useEffect(() => {
        getFoodData()
    }, [])
    const  dispatch = useDispatch()
    const  AddToCart=(food)=>{
       // {...food,qty:1}
       dispatch(addToCartAction(food))
    }


    function getFoodData()
    {
        axios.get("http://localhost:8080/food/"+id).then((response)=>{
          const result = response.data
          if(result.status==="success"){
              SetFood(result.data)
          }else{
              alert("No data found")
          }
        })
    }





    
    const classes= useStyle1()
    return (
        <div>
           <Paper Paper elevation="15" className={classes.vrContainer} >
          <img
          src={"http://localhost:8080/"+food.image}
          className={classes.foodImageCon} 
          />
          <div className={classes.foodDataCon}  >
              <Typography  variant="h3" align="left" color="inherit">
                  Food Name: {food.foodName}
              </Typography>
              <br/>
              <Typography  variant="h4" align="left" color="inherit">
                 Category: {food.catName}
              </Typography>
              <Typography  variant="h4" align="left" color="inherit">
                  Type: {food.type}
              </Typography>
              <Typography  variant="h5" align="left" color="inherit">
                  Description:{food.description}
              </Typography>
              <Typography  variant="h4"align=  "left"  color="inherit">
                 Price: ₹{food.price}
              </Typography>
              <br/>
                        <Button  variant="contained" onClick={()=>{AddToCart(food)}} size="Large" color="secondary">
                            Add
                        </Button >
          </div>
           </Paper>
           <br/>
            <Typography  variant="h3"align=  "left"  color="inherit">
                 Suggetions
            </Typography>
            <hr/>
           <br/>
           <HorizontalCon id={1}/>
           <br/>
           <HorizontalCon id={2}/>
           <br/>
        </div>
    )
}
