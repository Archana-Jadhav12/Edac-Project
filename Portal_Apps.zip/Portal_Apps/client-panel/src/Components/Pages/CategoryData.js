import React from 'react'
import { useParams } from 'react-router';
import VerticleCon from '../FoodContainers/VerticleCon';

export default function CategoryData() {
    const {id}= useParams()
    return (
        <div>
            <VerticleCon id={id}/>
        </div>
    )
}
