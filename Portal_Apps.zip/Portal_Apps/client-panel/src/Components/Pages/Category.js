import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useStyle1 } from '../FoodContainers/ContainerStyle'
import { CardActionArea, CardMedia, Paper, Typography, CardActions, Button, Card, CardContent, Box } from '@material-ui/core'
import HorizontalCon from './../FoodContainers/HorizontalCon';

export default function Category() {

    const [category , SetCategory]= useState([])
    const [foods , SetFoods]= useState([])
    const classes= useStyle1()
    const url="http://localhost:8080/"
    useEffect(() => {
        getCategory()
    }, [])

    function getCategory()
    {
        axios.get(url+"/food/category").then((response)=>{
          const result = response.data
          if(result.status==="success"){
            SetCategory(result.data)
          }else{
              alert("No data found")
          }
        })
    }


    return (
        <div>
             {category.map((cat)=>(
                 <div>
                       <HorizontalCon id={cat.id}/>
                       <br/>
                </div>
          
            
            ))}
        </div>
            
      
    )
}
