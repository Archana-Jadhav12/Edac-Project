import React from 'react'
import  AppBar from '@material-ui/core/AppBar';
import { Toolbar, Typography, Button, Box, InputBase, TableCell, IconButton } from '@material-ui/core';
import { useStyle } from './NavbarStyle';
import { NavLink, Switch, Route, useHistory } from 'react-router-dom';
import  SearchIcon  from '@material-ui/icons/Search';
import Badge from '@material-ui/core/Badge';
import { withStyles } from '@material-ui/core/styles';
import Profile from './Profile';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import { useSelector } from 'react-redux';
import { useState } from 'react';


const StyledBadge = withStyles((theme) => ({
    badge: {
      right: -3,
      top: 13,
      border: `2px solid ${theme.palette.background.paper}`,
      padding: '0 4px',
    },
  }))(Badge);
  

export default function Navbar() {
    const cartItems = useSelector((state) => state.cartItems)
    const classes= useStyle()
    const [name , setName]= useState('')


 function Search(){ 
   window.location.assign("http://localhost:3001/search/"+name)
 }





    return (
        <div>
           <AppBar className={classes.navbar}>
               <Toolbar className={classes.toolBar}>
       
                   <Typography variant="h3"  >Yummy Foods</Typography>
                  <Box style={{display:'flex',marginRight:10}} >
                  
                     <Profile/>   
                     
                  </Box>                 
               </Toolbar>

               
               <Box > 
               <Button className={classes.NavLinks}>
                    </Button>
               <Button className={classes.NavLinks} component={NavLink} to={"/home"} >
               <Typography variant="h6">Home</Typography>
                   </Button>
               <Button className={classes.NavLinks} component={NavLink} to={"/category"}>
                   <Typography variant="h6">Categories</Typography></Button>
               <Button className={classes.NavLinks}><Typography variant="h6">Veg-Only</Typography></Button>
               <Button className={classes.NavLinks}  ><Typography variant="h6">About us</Typography></Button>
               <Button className={classes.NavLinks} component={NavLink} to={"/cart"} >
               <IconButton aria-label="cart">
                  <StyledBadge badgeContent={cartItems.length} color="primary">
                    <ShoppingCartIcon fontSize='Large'/>
                     </StyledBadge>
                </IconButton>
                 </Button>
              
              
                <div className={classes.search} style={{float:"Right",marginRight:10}}>
                <form  action={"http://localhost:3001/search/"+name}> 
                                <div className={classes.searchIcon}>
                                <SearchIcon />
                                </div>
                                <InputBase
                                placeholder=""
                                onChange={(e) => {
                                    setName(e.target.value)
                                  }} 
                                classes={{
                                    root: classes.inputRoot,
                                    input: classes.inputInput,
                                }}
                                inputProps={{ 'aria-label': 'search' }}
                                />
                                <Button onClick={Search} >Search</Button>
                                </form>
                        </div>
                        
                        
               
               </Box>
           </AppBar>
     
        </div>
    )
}
