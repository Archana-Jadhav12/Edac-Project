import React, { useState } from 'react'
import { Box, Menu, MenuItem, IconButton, Avatar, ListItemText, Button, Typography } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Container from '@material-ui/core/Container';
import { NavLink } from 'react-router-dom';
import PersonIcon from '@material-ui/icons/Person';
import { useStyle } from './NavbarStyle';
import Signin from '../Pages/Signin';
import  Cookies  from 'universal-cookie';



export default function Profile() {
    const [open, setOpen] =useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
    const classes = useStyle();
    const cookie = new Cookies();
    const loggedin =cookie.get('name')
    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };
   
    const handleClose = () => {
      setAnchorEl(null);
    };

    //const [open, setOpen] =useState(false);

    const handleClickOpen = () => {
      setOpen(true);
    };
  
    const handleClose1 = () => {
      setOpen(false);
    };
    function LogOut(){
        cookie.remove("name")
        cookie.remove("LastName")
        cookie.remove("id")
        window.location.assign("http://localhost:3001/home")
        //window.location.reload()

    }

    if(loggedin){
        return(
            <div>
            <IconButton className={classes.profile} aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick}>
                     <Avatar ><PersonIcon color='action' /></Avatar>
                </IconButton>
                <Menu
                anchorEl={anchorEl}
                keepMounted
                className={classes.profile}
                open={Boolean(anchorEl)}
                onClose={handleClose}
                >
                     <MenuItem component={NavLink} to={"/profile"}  onClick={handleClose}> 
                     <Button  >
                        <ListItemText >
                           <Typography style={{color:"Black"}} variant="h6" >Profile</Typography> </ListItemText>
                    </Button>
                    </MenuItem>
                    <MenuItem  component={NavLink} to={"/ordersdata"} onClick={handleClose}> 
                     <Button >
        
                        <ListItemText><Typography style={{color:"Black"}} variant="h6">Orders</Typography></ListItemText>
                    </Button>
                    </MenuItem>
                    <MenuItem  onClick={LogOut}> 
                    <Button  >
                        <ListItemText><Typography style={{color:"Black" }} variant="h6">Log out</Typography></ListItemText>
                    </Button>
                    </MenuItem>
                    </Menu> 
            </div>

        )

    }else{

        return ( <Signin/>)
            
    }

}
