import React, { useEffect, useState } from 'react'
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, withStyles } from '@material-ui/core'
import { cartstyle } from '../Cart/cartStyle';
import axios from 'axios';
import Cookies from 'universal-cookie/es6';




export default function Orders() {
    const cookie = new Cookies();
    const ID = cookie.get("id")
    console.log(ID)
    const classes = cartstyle();
    const [OrdersData, setOrdersData] = useState([])
  
    useEffect(() => {
        getOrdersData()
      },[])
    function getOrdersData()
    { 
        axios.get("http://localhost:8080/orders/"+ID).then((response)=>{
          const result = response.data
    
          if(result.status==="success"){
            setOrdersData(result.data)
          }else{
              alert("No data found")
          }
        })
    }
    


    return (
        <div>
             <br/>
             <Typography variant="h3" align='center' >Orders History</Typography>
            <br/>
                <Paper elevation={15} className={classes.tableCon} >

                <TableContainer  >
                                <Table className={classes.table} aria-label="customized table">
                                <TableHead>
                                        <TableRow>
                                            <StyledTableCell align="left">Order ID</StyledTableCell>
                                            <StyledTableCell align="left">Delivery Address</StyledTableCell>
                                            <StyledTableCell align="left">Phone</StyledTableCell>
                                            <StyledTableCell align="left">Payment Mode</StyledTableCell>
                                            <StyledTableCell align="left">Bill Amount</StyledTableCell>
                        </TableRow>
                        </TableHead>
                        <TableBody>
                        {OrdersData.map((order)=>(

                            <StyledTableRow >
                            <StyledTableCell component="th" scope="row">
                            {order.id} 
                            </StyledTableCell>
                            <StyledTableCell align="left">{order.dAddress}</StyledTableCell>
                            <StyledTableCell align="left">{order.phone}</StyledTableCell>
                            <StyledTableCell align="left">{order.paymentType}</StyledTableCell>
                            <StyledTableCell align="left">{order.totalAmount}</StyledTableCell>  
                            </StyledTableRow>

                                ))}

                       
                            
                        
                        </TableBody>
                    </Table>
                    </TableContainer>

                </Paper>
        </div>
    );
}

const StyledTableCell = withStyles((theme) => ({
    head: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
      fontSize: 25,
    },
    body: {
      fontSize: 25,
    },
  }))(TableCell);

  const StyledTableRow = withStyles((theme) => ({
    root: {
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
      },
    },
  }))(TableRow);
