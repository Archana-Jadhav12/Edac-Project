export const addToCartAction =(food)=>{

    return{
        type:'add-to-cart',
        food: food,
    }
}

export const removeFromCartAction =(food)=>{
    return{
        type:'remove-from-cart',
        food: food,
    }
}
