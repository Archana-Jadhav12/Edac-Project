
import { BrowserRouter, Route ,Redirect} from 'react-router-dom';
import './App.css';
import AdminPannel from './Components/Pannels/AdminPannel';
import Login from './Components/Pannels/Login';
import  Cookies  from 'universal-cookie';
import StaffPannel from './Components/Pannels/StaffPannel';

function App() {

  const cookie = new Cookies()
  let auth = false

  if(cookie.get("empName" )!== undefined){
  auth = true
  }


  

    if(auth ===true){

          if(cookie.get("role")==="admin")
          {
            return(<BrowserRouter>
              <Redirect exact to="/admin" />
              <Route  path="/admin"><AdminPannel/></Route>
                </BrowserRouter>)

          }else if(cookie.get("role")==="Staff")
          {
            return(<BrowserRouter>
              <Redirect exact to="/staff/user" />
              <Route  path="/staff"><StaffPannel/></Route>
                </BrowserRouter>)

          }else{
            return(
              <BrowserRouter>
                <Redirect to="/login" />
                <Route exact path="/login" render={()=><Login/>}/>
                </BrowserRouter>
                )
          }

    }else{
      return(
      <BrowserRouter>
        <Redirect to="/login" />
        <Route exact path="/login" render={()=><Login/>}/>
        </BrowserRouter>
        )

    }

// return (  
//  <BrowserRouter>
//   <Switch>
//   <Route  path="/admin"><AdminPannel/></Route>
//   <Route  path="/login" render={()=><Login/>}/>
//   </Switch>
//   </BrowserRouter>
 
// )

  
 
}
export default App;
