import { makeStyles } from "@material-ui/core";
import { blueGrey, red } from "@material-ui/core/colors";




export const useStyle = makeStyles((theme)=>({
    
    foodName:{
   
       textAlign:"top"


    },



    scrollDiv:{
       // display: "flex",
       flexWrap:"wrap",
        height:800,
        width:"100%",
        padding: 20,
        overflow: "auto",

    }
    ,
    
    image:{
        height:"200px",
        width:"200px"

    },
    imageSm:{
        height:"200px",
        width:"200px"

    },
    
    imageComponent:{
     
        height:250,
        width:350

    },


    title:{
        marginLeft:25
      
    },
    
    profile:{
        marginTop:15,
        marginLeft:250,
        marginRight:20
    },
    
    toolBar:{
        display: "flx",
        flexFlow: "row wrap",
        justifyContent: "space-between"
    },

    NavBar:{
    backgroundColor: "#40CEFE",
    height: "100px"
    },
    activeNavLink:
    {
        backgroundColor:"#40CEFE" ,
        borderRadius: "10px"
    },

    drawerPaper:{
        width: "300px",
        marginTop:"93px",
        backgroundColor:"#101A32",
        color:"white" ,
        borderRadius: "10px"
    },
    
    drawericon :
    {
        color:"White"
    },

    navLink:
    {
        color: "White",
        "& :hover,&:hover div ":{
            color: blueGrey["A400"]
        },
        "&: div":{
        color:"White",
         backgroundColor:blueGrey["A400"]},
        height:"80px"
    },

    link:{
        textDecoration:"None",
    },
    
    EditPaper:{
        marginLeft:350,
        width:650,
        padding:30
    },

     detailsButton:{
          
            marginLeft: 250,
            marginRight:250
      
    },

    detailsBoxContainer:{
      
        marginLeft: 150,
        marginRight:250
    },
    detailsText:{
        marginTop:30,
        marginLeft: 150,
        marginRight:250
    },

    editTxt:{
        
        marginTop:30,
        margin:10
    },
    

    //Wrappr of main container
    wrapper:
    {
      
      
        flexDirection:"column",
        height:850,
        overflow: "hidden",
        padding: theme.spacing(2,2,95,40),
      
    },

    button:{ 
    
        textDecoration:"none",
      
                marginRight:100
    },

    tableHead:{
        color:"White",
        backgroundColor: "#BDBDBD"
        
       
    },

    paper: {
        marginTop: theme.spacing(30),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      },
      avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
      },
      form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
      },
      submit: {
        margin: theme.spacing(3, 0, 2),
      },


}));
