import React, { useState } from 'react'
import { Box,  Menu, MenuItem, IconButton, Avatar, ListItem, ListItemIcon, ListItemText, Button } from '@material-ui/core';
import SettingsIcon from '@material-ui/icons/Settings';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import PermIdentityIcon from '@material-ui/icons/PermIdentity';
import { useStyle } from './../HeaderStyle';
import  Cookies  from 'universal-cookie';
import { NavLink } from 'react-router-dom';
import PersonIcon from '@material-ui/icons/Person';




export default function Profile() {

    const [anchorEl, setAnchorEl] = useState(null);
    const classes = useStyle();
    const cookie= new Cookies()
    const path = cookie.get("role")
    function LogOut(){
        cookie.remove("empName")
        cookie.remove("role")
        cookie.remove("empId")
        window.location.reload()

    }
   
    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };
   
    const handleClose = () => {
      setAnchorEl(null);
    };



    return (
        <Box>
             <IconButton className={classes.profile} aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick}>
                 <Avatar ><PersonIcon /></Avatar>
            </IconButton>
            <Menu
            id="simple-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
            >
                 <MenuItem  component={NavLink} to={"/"+path+"/details"} onClick={handleClose}> 
                 <Button  >
                    <ListItemIcon><PermIdentityIcon/></ListItemIcon>
                    <ListItemText>Profile</ListItemText>
                </Button>
                </MenuItem>
                <MenuItem  component={NavLink} to={"/"+path+"/setting"} onClick={handleClose}> 
                 <Button  >
                    <ListItemIcon><SettingsIcon/></ListItemIcon>
                    <ListItemText>Settings</ListItemText>
                </Button>
                </MenuItem>
                <MenuItem  onClick={handleClose}> 
                <Button onClick={LogOut} >
                    <ListItemIcon ><ExitToAppIcon/></ListItemIcon>
                    <ListItemText>LogOut</ListItemText>
                </Button>
                </MenuItem>
                </Menu> 

        </Box>
    )
}
