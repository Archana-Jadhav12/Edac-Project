import React from 'react'
import { Divider, List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core'
import PeopleIcon from '@material-ui/icons/People';
import PersonOutlineIcon from '@material-ui/icons/PersonOutline';
import FastfoodIcon from '@material-ui/icons/Fastfood';
import DnsIcon from '@material-ui/icons/Dns';
import ViewListIcon from '@material-ui/icons/ViewList';
import DashboardIcon from '@material-ui/icons/Dashboard';
import { useStyle } from './HeaderStyle';
import { NavLink } from 'react-router-dom';
import  Cookies  from 'universal-cookie';



export default function SidenavData() {
  const classes = useStyle();
  const cookie = new Cookies()
  const path = cookie.get("role")
  const listItemData =[
    {lable:"DashBoard",
      link:"/Admin",
        icon: <DashboardIcon/> ,
       
      } ,  
    
    {lable:"Employee",
      link:"/Admin/emp",
        icon: <PeopleIcon/> ,
      
      } ,
        {lable:"User",
        link:"/Admin/user",
        icon: <PersonOutlineIcon/> ,
         },

        {lable:"Food",
        link:"/Admin/food",
        icon:<FastfoodIcon/> ,
         },

        {lable:"Category",
        link:"/Admin/category",
        icon: <DnsIcon/>,
          },

        {lable:"Orders",
        link:"/Admin/orders",
        icon: <ViewListIcon/>,
           },
  ]


  return (
    <List>
      {listItemData.map((item ,i )=>(
          <ListItem key={i} exact component={NavLink} to={item.link} className={classes.navLink}   activeClassName={classes.activeNavLink} >
            <ListItemIcon className={classes.drawericon}>{item.icon}</ListItemIcon>
            <ListItemText>{item.lable}</ListItemText>
            <Divider variant="inset" component="li" />
          </ListItem>
      ))}

    </List>
  )
}
