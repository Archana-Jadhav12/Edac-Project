import React from 'react'
import { Divider, List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core'
import PersonOutlineIcon from '@material-ui/icons/PersonOutline';
import FastfoodIcon from '@material-ui/icons/Fastfood';
import DnsIcon from '@material-ui/icons/Dns';
import ViewListIcon from '@material-ui/icons/ViewList';
import { useStyle } from './HeaderStyle';
import { NavLink } from 'react-router-dom';
import  Cookies  from 'universal-cookie';



export default function StaffSidenavData() {
  const classes = useStyle();
  const cookie = new Cookies()
  const path = cookie.get("role")
  const listItemData =[
        {lable:"User",
        link:"/"+path+"/user",
        icon: <PersonOutlineIcon/> ,
         },

        {lable:"Food",
        link:"/"+path+"/food",
        icon:<FastfoodIcon/> ,
         },

        {lable:"Category",
        link:"/"+path+"/category",
        icon: <DnsIcon/>,
          },

        {lable:"Orders",
        link:"/"+path+"/orders",
        icon: <ViewListIcon/>,
           },
  ]


  return (
    <List>
      {listItemData.map((item ,i )=>(
          <ListItem key={i} exact component={NavLink} to={item.link} className={classes.navLink}   activeClassName={classes.activeNavLink} >
            <ListItemIcon className={classes.drawericon}>{item.icon}</ListItemIcon>
            <ListItemText>{item.lable}</ListItemText>
            <Divider variant="inset" component="li" />
          </ListItem>
      ))}

    </List>
  )
}
