import React from 'react'
import { Route, Switch } from 'react-router';
import Navbar from './Navbar';
import Sidenav from './Sidenav';
import Dashboard from './../Body/DashBoard/Dashboard';
import { Box } from '@material-ui/core';
import { useStyle } from './HeaderStyle';
import Employee from './../../Pages/EmployeePages/Employee';
import EmployeeData from './../../Pages/EmployeePages/EmployeeData';
import UserData from './../../Pages/User/UserData';
import AddEmployee from './../../Pages/EmployeePages/AddEmployee';
import EditEmployee from './../../Pages/EmployeePages/EditEmployee';
import EditUser from './../../Pages/User/EditUser';
import User from '../../Pages/User/User';
import Login from './../Pannels/Login';


export default function HeaderComponent({navbar}) {
    const classes =useStyle()

    return (
        <Box>
           <Navbar title={navbar}/>
        </Box>

    )
}
