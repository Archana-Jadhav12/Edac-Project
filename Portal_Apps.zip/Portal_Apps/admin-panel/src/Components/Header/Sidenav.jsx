import React from 'react'
import { Drawer,  } from '@material-ui/core'

import SidenavData from './SidenavData';
import { useStyle } from './HeaderStyle';



export default function Sidenav({Data}) {
    const classes = useStyle();
    return (
        <nav className={classes.drawer} aria-label="mailbox folders">
          <Drawer
            classes={{
              paper: classes.drawerPaper,
            }}
            anchor={'left'}
            variant="permanent"
            
          >
           {/* <SidenavData/> */}
           <Data/>
          </Drawer>
    
      </nav>
    )
}
