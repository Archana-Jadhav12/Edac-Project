import React from 'react'
import { AppBar, Box,  makeStyles,   Toolbar,  Typography } from '@material-ui/core'
import Profile from './Navtabs/Profile';
import { useStyle } from './HeaderStyle';



export default function Navbar({title}) {
 const classes = useStyle();

    return (
        <AppBar className={classes.NavBar} position="static">
        <Toolbar className={classes.toolBar}>
          <Typography variant="h4" className={classes.title}>
            {title}
          </Typography>
          <Box> 
            <Profile/>
          </Box>
        </Toolbar>
      </AppBar>
    )
}
