import React from 'react'
import HeaderComponent from './../Header/HeaderComponent';
import { Route, Switch } from 'react-router-dom';
import Employee from '../../Pages/EmployeePages/Employee';
import EditEmployee from './../../Pages/EmployeePages/EditEmployee';
import EditUser from './../../Pages/User/EditUser';
import AddEmployee from './../../Pages/EmployeePages/AddEmployee';
import UserData from './../../Pages/User/UserData';
import User from '../../Pages/User/User';
import Dashboard from './../Body/DashBoard/Dashboard';
import { Box } from '@material-ui/core';
import { useStyle } from '../Header/HeaderStyle';
import Login from './Login';
import EmployeeDetails from './../../Pages/EmployeePages/EmployeeDetails';
import Details from './../../Pages/Details';
import Settings from './../../Pages/Settings';
import Sidenav from './../Header/Sidenav';
import SidenavData from './../Header/SidenavData';
import Foods from './../../Pages/Food/Foods';
import AddFood from './../../Pages/Food/AddFood';
import EditFood from './../../Pages/Food/EditFood';
import Categories from './../../Pages/Category/Categories';
import mainBox from '../../mainBox.css'
import Orders from '../../Pages/Orders/Orders';

export default function AdminPannel() {
    const classes =useStyle()
   
    return (
        <div>
            <HeaderComponent navbar="Admin Pannel"/>
            <Sidenav Data={SidenavData}/>
            <Box className={classes.wrapper}>
            <Switch>
                <Route  path='/Admin/emp' render={()=> <Employee />}  />
                <Route exact path='/Admin/edit-user/:id' ><EditUser/></Route>
                <Route exact path='/Admin/add-emp' render={()=><AddEmployee/>}  />
                <Route exact path='/Admin/user/:id' render={()=><UserData/>}  />
                <Route exact path="/Admin/user" render={()=><User />}  />
                <Route exact path='/Admin/edit-emp/:id' ><EditEmployee/></Route>
                <Route exact path='/Admin/employee/:id' ><EmployeeDetails/></Route>
                <Route exact path='/Admin/details' ><Details/></Route>
                <Route exact path='/Admin/setting' ><Settings/></Route>
                <Route exact path='/Admin/food' ><Foods/></Route>
                <Route exact path='/Admin/orders' ><Orders/></Route>
                <Route exact path='/Admin/addfood' ><AddFood/></Route>
                <Route exact path='/Admin/edit-food/:id'><EditFood/></Route>
                <Route exact path='/Admin/category'><Categories/></Route>
                <Route exact path="/login" render={()=> <Login/>}/>
                <Route exact path="/admin" render={()=> <Dashboard/>}/>
            </Switch>
           </Box> 
        </div>
    )
}
