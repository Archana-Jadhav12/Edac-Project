import React, { useState } from 'react'
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import { useStyle } from '../Header/HeaderStyle';
import axios from 'axios';
import Cookies from 'universal-cookie';
import { Collapse, IconButton } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import  CloseIcon  from '@material-ui/icons/Close';
import { useHistory } from 'react-router-dom';

export default function Login() {
    const [email, setEmail] = useState()
    const [password, setPassword] = useState()
    const classes = useStyle();
    const [error, setError] =useState(false);
    const cookie = new Cookies();



 function Authenticate(e){
 const data = new FormData()
 data.append("email", email)
 data.append("password", password)



         axios.post('http://localhost:8080/emp/auth',data).then((response)=>{
         const result = response.data
             if(result.status==="success"){
                 console.log(result)
                 cookie.set("empName", result.data.firstName,{ path: '/' },{maxAge :10})
                 cookie.set("role", result.data.role,{ path: '/' },{maxAge :10})
                 cookie.set("empId", result.data.id,{ path: '/' },{maxAge :10})
           }else{
               setError(true)
             }
        })

 }

    return (
      <div className="container">
        <br/>
 <Collapse in={error}>
          <Alert   variant="filled" severity="error"
            action={
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => {
                  setError(false);
                }}
              >
                <CloseIcon fontSize="inherit" />
              </IconButton>
            }
          >
         Wrong Email or Password !!
          </Alert>
      </Collapse>
        <Container component="main" maxWidth="xs">
        <div className={classes.paper}>
          <Avatar className={classes.avatar}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Log in
          </Typography>
          <form className={classes.form} noValidate>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              onChange={(e) => {
                setEmail(e.target.value)
              }} 
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              onChange={(e) => {
                setPassword(e.target.value)
              }} 
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
            />
           
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              onClick={Authenticate}
              className={classes.submit}
            >
             Log in
            </Button>
          </form>
        </div>
      </Container>
      </div>

    );
}
