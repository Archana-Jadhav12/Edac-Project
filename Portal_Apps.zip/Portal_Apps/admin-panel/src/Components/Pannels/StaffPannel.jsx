import React from 'react'
import HeaderComponent from '../Header/HeaderComponent';
import { Route, Switch } from 'react-router-dom';
import Employee from '../../Pages/EmployeePages/Employee';
import EditEmployee from '../../Pages/EmployeePages/EditEmployee';
import EditUser from '../../Pages/User/EditUser';
import AddEmployee from '../../Pages/EmployeePages/AddEmployee';
import UserData from '../../Pages/User/UserData';
import User from '../../Pages/User/User';
import Dashboard from '../Body/DashBoard/Dashboard';
import { Box } from '@material-ui/core';
import { useStyle } from '../Header/HeaderStyle';
import Login from './Login';
import EmployeeDetails from '../../Pages/EmployeePages/EmployeeDetails';
import Details from '../../Pages/Details';
import Settings from '../../Pages/Settings';
import  Cookies  from 'universal-cookie';
import StaffSidenavData from './../Header/StaffSidenavData';
import Sidenav from './../Header/Sidenav';
import Categories from './../../Pages/Category/Categories';
import Foods from './../../Pages/Food/Foods';
import AddFood from './../../Pages/Food/AddFood';
import EditFood from './../../Pages/Food/EditFood';
import Orders from '../../Pages/Orders/Orders';

export default function StaffPannel() {
 
    const classes =useStyle()
    const cookie = new Cookies()
    const path = cookie.get("role")
   
    return (
        <div>
            <HeaderComponent navbar="Staff"/>
            <Sidenav Data={StaffSidenavData}/>
            <Box className={classes.wrapper}>
           <Switch>
                <Route  path='/Staff/emp' render={()=> <Employee url ={"/admin"}/>}  />
                <Route exact path='/Staff/edit-user/:id' ><EditUser/></Route>
                <Route exact path='/Staff/user/:id' render={()=><UserData/>}  />
                <Route exact path="/Staff/user" render={()=><User url ={"/admin"}/>}  />
                <Route exact path='/Staff/details' ><Details/></Route>
                <Route exact path='/Staff/setting' ><Settings/></Route>
                <Route exact path='/Staff/category'><Categories/></Route>
                <Route exact path='/Staff/food' ><Foods/></Route>
                <Route exact path='/Staff/orders' ><Orders/></Route>
                <Route exact path='/Staff/addfood' ><AddFood/></Route>
                <Route exact path='/Staff/edit-food/:id'><EditFood/></Route>
                <Route exact path="/login" render={()=> <Login/>}/>
                <Route exact path="/Staff" render={()=> <Dashboard/>}/>
            </Switch>
           </Box> 
        </div>
    )
}
