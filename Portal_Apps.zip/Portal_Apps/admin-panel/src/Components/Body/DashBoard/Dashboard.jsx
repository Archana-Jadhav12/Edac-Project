import React from 'react'

export default function Dashboard() {
    return (
        <div className="container">
            <h1>Dashbord </h1>
        </div>
    )
}
