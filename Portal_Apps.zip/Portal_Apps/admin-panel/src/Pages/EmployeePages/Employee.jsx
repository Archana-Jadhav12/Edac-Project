
import { React,useState, useEffect } from 'react'
import axios from 'axios'
import { Box, Button, Table, TableBody, TableCell,  TableHead, TableRow, Typography } from '@material-ui/core'
import Paper from '@material-ui/core/Paper';
import { useStyle } from '../../Components/Header/HeaderStyle';
import { NavLink } from 'react-router-dom';
import  Cookies  from 'universal-cookie';




function Employee() {
  const cookies = new Cookies()
  const path = cookies.get("role")
 
    const classes = useStyle();
    const [employees, setEmployees] = useState([])
    useEffect(() => {
      getEmployee()
    }, [])
    

    function getEmployee(){
        axios.get("http://localhost:8080/emp").then((response)=>{
          const result = response.data
          if(result.status==="success"){
            setEmployees(result.data)
          }else{

          }
        })
    }
 

    
    return (
     
        <Box>

          
            <Button  className={classes.link} component={NavLink} to={'/admin/add-emp'} variant="contained" color="primary">
                Add Employee
            </Button>
        <br/>
        <br/>
        <Paper  elevation={15} >
        <Table className={classes.table} aria-label="customized table">
          <TableHead className={classes.tableHead}>
            <TableRow>
              <TableCell align="left" ><Typography variant="h6">Id</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Name</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Email</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Role</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Action</Typography></TableCell>
            </TableRow>
          </TableHead>
         
          <TableBody>
            {employees.map((emp,i) => ( 
            <TableRow key={i} className={classes.link} component={NavLink}  to={'/Admin/employee/'+ emp.id}>
                <TableCell align="left" component="th" scope="row" >
                <Typography >{emp.id}</Typography>  </TableCell>
                <TableCell align="left" >
                <Typography >{emp.firstName} {emp.lastName}</Typography>
                </TableCell>
                <TableCell align="left">
                <Typography > {emp.email}</Typography>
                  </TableCell>
                <TableCell align="left">
                <Typography > {emp.role}</Typography>
                  </TableCell>
                <TableCell align="left"><Button className={classes.link}variant="outlined" color="primary" component={NavLink} to={'/'+path+'/edit-emp/'+emp.id} >Edit</Button></TableCell>
            </TableRow>
            ))}
          </TableBody>
          
        </Table>
       
      </Paper>


     
 </Box>
     
    )
}

export default Employee
