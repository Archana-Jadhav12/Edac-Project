import React, { useEffect, useState } from 'react'
import {Button,  Collapse,  Menu,  Paper, TextField} from '@material-ui/core'

import CloseIcon from '@material-ui/icons/Close';
import axios from 'axios';

import { useStyle } from '../../Components/Header/HeaderStyle';

import { MenuItem, IconButton, Typography } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';



export default function AddEmployee() {
    const classes = useStyle()
    const [firstName, setFirstName] = useState([])
    const [lastName, setLastName] = useState([])
    const [email, setEmail] = useState([])
    const [password, setPassword] = useState([])
    const [phone, setPhone] = useState([])
    const [address, setAddress] = useState([])
    const [role, setRole] = useState([])

    const [open, setOpen] =useState(false);
    const [error, setError] =useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
   
  const setAdmin=()=>{
        setRole("Admin")
    }
    const setStaff=()=>{
      setRole("Staff")
  }
  const setDel=()=>{  
    setRole("Delivery")
    }

    


    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };






    const AddEmployee=()=>{

        if( firstName.length ===0){
          setError(true)
        }else if(lastName.length===0){
          setError(true)
        }else if(email.length===0){
          setError(true)
        }else if(password.length===0){
          setError(true)
        }else if(phone.length===0){
          setError(true)
        }else if(address.length===0){
          setError(true)
        }else if(role.length===0){
          setError(true)
        }else{

          const data = new FormData()
          data.append('id', 0 )
          data.append('firstName', firstName )
          data.append('lastName', lastName )
          data.append('email', email )
          data.append('password', password )
          data.append('phone', phone )
          data.append('address', address )
          data.append('role', role )

         

        axios.post('http://localhost:8080/emp/addemp',data).then((response)=>{
          const result = response.data
          console.log(result)
              if(result.status==="success"){
                setOpen(true)
              }else{
                alert("No data found")
              }
            })
        }
    }
    
    return (
       
     <div >  
        <Collapse in={error}>
          <Alert   variant="filled" severity="error"
            action={
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => {
                  setError(false);
                }}
              >
                <CloseIcon fontSize="inherit" />
              </IconButton>
            }
          >
          Some Field Is Missing .
          </Alert>
      </Collapse>
        <Collapse in={open}>
          <Alert   variant="filled"
            action={
              <IconButton
            
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => {
                  setOpen(false);
                }}
              >
                <CloseIcon fontSize="inherit" />
              </IconButton>
            }
          >
          Employee Added Successfuly .
          </Alert>
      </Collapse>

          <br/>


        <Paper elevation={20} className={classes.EditPaper} >
                <Typography align="center"  variant="h5" >Add Employee</Typography>
                <br/>

            <div>
            <form  >
                    <div >
              
                        <TextField
                        className={classes.editTxt} 
                        id="standard-read-only-input"
                        label="Id:"
                        value="Auto"
                       
                        />
                      </div>
                    <div>
                      <TextField onChange={(e) => {
                                                  setFirstName(e.target.value)
                                                }} 
                           className={classes.editTxt} margin="dense" 
                          label="First Name" />

                      <TextField onChange={(e) => {
                                                  setLastName(e.target.value)
                                                }} 
                          className={classes.editTxt} margin="dense" 
                          label="Last Name" />
                   </div>
                    <div>
                        <TextField onChange={(e) => {
                                                  setEmail(e.target.value)
                                                }} 
                        margin="dense" type="email" 
                        className={classes.editTxt} 
                        fullWidth id="standard-email-input"
                        label="Eamil"/>
                    </div>
            
                     <div>
                        <TextField margin="dense" onChange={(e) => {
                                                  setPassword(e.target.value)
                                                }} 
                        className={classes.editTxt}
                        type="password" size="medium" 
                        id="standard-password-input" 
                        label="Password" />

                        <TextField onChange={(e) => {
                                                  setPhone(e.target.value)
                                                }} 
                        margin="dense"
                        className={classes.editTxt}
                        id="standard-number"
                        label="Phone"
                        type="number"
                        />
                    </div>
                    <div>
                        <TextField margin="dense" type="text"
                        onChange={(e) => {
                          setAddress(e.target.value)
                        }} 
                        className={classes.editTxt}
                        id="outlined-multiline-static" 
                        multiline
                         rows={4}
                        label="Address" />

                           
                        <Button  className={classes.editTxt} variant="outlined" aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick}>
                          ROLE
                        </Button>
                        <Menu
                          id="simple-menu"
                          anchorEl={anchorEl}
                          keepMounted
                          open={Boolean(anchorEl)}
                          onClose={handleClose}
                        >
                          <MenuItem onClick={handleClose}> <Button onClick={setAdmin} > Admin </Button></MenuItem>
                          <MenuItem onClick={handleClose }><Button onClick={setStaff} > Staff </Button></MenuItem>
                          <MenuItem onClick={handleClose} ><Button onClick={setDel} > Delivery </Button></MenuItem>
                        </Menu>
                    
                           
                         
                    </div>
                    </form>
                <br/>
          
            </div>
            <br/>
            <br/>
            <Button onClick={AddEmployee} variant="outlined" color="primary">
             Add 
        </Button>
        </Paper>

      
    </div>    
       
    )
}
