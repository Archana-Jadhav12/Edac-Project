import { React,useState, useEffect } from 'react'
import {Button, Paper,Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@material-ui/core'
import { useStyle } from './../../Components/Header/HeaderStyle';
import  axios from 'axios'


export default function Categories() {
    const classes =useStyle()
    const [categories, setCategories] = useState([])
    const [cat, setCat] = useState([])

    useEffect(() => {
        getCategories()
      }, [])
  

    function getCategories(){
        axios.get("http://localhost:8080/food/category").then((response)=>{
          const result = response.data
          console.log(result)
          if(result.status==="success"){
           setCategories(result.data)
          }else{
              alert("something went wrong")
          }

        })
    }

    return (
        <div>
            <Button  className={classes.link} variant="contained" color="secondary">
                Add Category
            </Button>
            <hr/>
        <div className={classes.scrollDiv}>
            <Paper elevation={15}>
            <Table>
            <TableHead className={classes.tableHead}>
            <TableRow>
              <TableCell align="center" ><Typography variant="h5" >Id</Typography></TableCell>
              <TableCell align="center"><Typography variant="h5">Category</Typography></TableCell>
              <TableCell align="center"><Typography variant="h5">Time Stamp</Typography></TableCell>
              <TableCell align="center"><Typography variant="h5">...</Typography></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
        { categories.map((category)=>( 
            <TableRow>
            <TableCell align="center" ><Typography variant="h6" >{category.id}</Typography></TableCell>
            <TableCell align="center"><Typography variant="h6">{category.categoryName}</Typography></TableCell>
            <TableCell align="center"><Typography variant="h6">{category.timeStamp}</Typography></TableCell>
            <TableCell align="center"><Typography variant="h6">
            <Button className={classes.link}variant="outlined" color="secondary" > 
            Delete</Button>
                </Typography></TableCell>
          </TableRow>

          ))}
          


          </TableBody>
            </Table>
            </Paper>
            
            </div>
        </div>
    )
}
