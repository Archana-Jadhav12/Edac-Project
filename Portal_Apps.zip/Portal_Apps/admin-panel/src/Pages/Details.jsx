import React, { useEffect, useState  } from 'react'
import { useHistory } from 'react-router-dom';
import axios from 'axios'
import { Box, Paper, Typography, Table, TableCell, TableRow, TableBody, Button } from '@material-ui/core';
import  Cookies  from 'universal-cookie';
import { useStyle } from './../Components/Header/HeaderStyle';


export default function Details() {
    const history= useHistory()
    const classes = useStyle();
    const cookie = new Cookies
    const id = cookie.get("id")
    const [employees, setEmployees] = useState([])

 
    useEffect(() => {
        getEmployee()
      },[])


    function getEmployee(){
        axios.get('http://localhost:8080/emp/'+id).then((response)=>{
          const result = response.data
          if(result.status==="success"){
            
            setEmployees(result.data)
          }else{
            alert("No data found")
          }
        })
    }
   

    return (
        <Box>
        <Paper className={classes.detailsBoxContainer} elevation={15}  >
            <Table className={classes.detailsbox} aria-label="caption table">
                <TableBody>
                <TableRow >
                <TableCell align="Left"> <Typography variant="h6">Id :</Typography></TableCell>
                <TableCell align="Left"> <Typography variant="h6">{employees.id}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">First Name :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.firstName}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Last Name : </Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.lastName}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Email :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.email}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Password :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.password}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Phone :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.phone}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Address :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.address}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Role : </Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.role}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Joining Date :  </Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{employees.timeStamp}</Typography></TableCell>
                </TableRow>
            </TableBody>
        </Table>
    </Paper>
    <br/>
    <br/>
         
</Box>
    )
}
