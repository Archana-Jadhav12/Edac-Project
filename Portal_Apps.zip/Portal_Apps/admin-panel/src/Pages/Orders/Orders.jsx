import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';
import { useStyle } from '../../Components/Header/HeaderStyle';
import axios from 'axios'
import { Box, Button, Paper, Table, TableBody, TableCell,  TableHead, TableRow, Typography } from '@material-ui/core'
export default function Orders() {
    const classes = useStyle();
    const [OrdersData, setOrdersData] = useState([])
    useEffect(() => {
        getOrdersData()
    }, [])


    function getOrdersData()
    { 
        axios.get("http://localhost:8080/all-orders").then((response)=>{
          const result = response.data
    
          if(result.status==="success"){
            setOrdersData(result.data)
           
          }else{
              alert("No data found")
          }
        })
    }


    return (
        <div>
            
            <br/>
        <br/>
        <Paper  elevation={15} >
        <Table className={classes.table} aria-label="customized table">
          <TableHead className={classes.tableHead}>
            <TableRow>
              <TableCell align="left" ><Typography variant="h6">Order Id</Typography></TableCell>
              <TableCell align="left" ><Typography variant="h6">USer Id</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Delivery Address</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Phone</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Payment Mode</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Amount</Typography></TableCell>
            </TableRow>
          </TableHead>
         
          <TableBody>
            {OrdersData.map((order,i) => ( 
            <TableRow key={i} className={classes.link} >
                <TableCell align="left" component="th" scope="row" >
                <Typography >  {order.id} </Typography>  </TableCell>
                <TableCell align="left" component="th" scope="row" >
                <Typography >  {order.userId} </Typography>  </TableCell>
                <TableCell align="left" >
                <Typography > {order.dAddress}</Typography>
                </TableCell>
                <TableCell align="left">
                <Typography > {order.phone}</Typography>
                  </TableCell>
                <TableCell align="left">
                <Typography >{order.paymentType}</Typography>
                  </TableCell>
                <TableCell align="left">   <Typography >{order.totalAmount}</Typography></TableCell>
            </TableRow>
            ))}
          </TableBody>
          
        </Table>
       
      </Paper>



        </div>
    )
}
