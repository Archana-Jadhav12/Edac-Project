import { React,useState, useEffect } from 'react'
import {  Button, Dialog, DialogContent, DialogContentText, DialogTitle, Paper,  Table, TableCell, Typography } from '@material-ui/core';
import { useStyle } from './../../Components/Header/HeaderStyle';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
import { DialogActions } from '@material-ui/core';
import Cookies  from 'universal-cookie';


export default function Foods() {
  const cookies = new Cookies()
  const path = cookies.get("role")
    const classes = useStyle();
    const history = useHistory()
    const[id ,setId]= useState([]);
    const [open, setOpen] = useState(false);
    const [foods, setFoods] = useState([])
    useEffect(() => {
        getFoodData()
    }, [])
    // const Transition = React.forwardRef(function Transition(props, ref) {
    //     return <Slide direction="up" ref={ref} {...props} />;
    //   });

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    DeleteFood();
    setOpen(false);
  };
  const handleJustClose = () => {
    setOpen(false);
  };
    
    function getFoodData()
    {
        axios.get("http://localhost:8080/food").then((response)=>{
          const result = response.data
          if(result.status==="success"){
            setFoods(result.data)
          }else{
              alert("No data found")
          }
        })
    }


    function DeleteFood(){ 
        axios.delete("http://localhost:8080/food/delete/"+id).then((response)=>{
            const result = response.data
            console.log(result)
            if(result.status==="success"){
                history.push("/Admin/food")
                
            }else{
               
            }
          })
    }



    return (
        <div  >
             <Button  className={classes.link} component={NavLink} to={'/admin/addfood'}  variant="contained" color="secondary">
                Add Food Item
            </Button>
            <hr/>

        <div className={classes.scrollDiv} >
            {foods.map((food, i)=>( 
                <div>
                <Paper elevation={15}>
                <Table>
                    <TableCell  className={classes.imageComponent} align="left" > 
                       <br/>
                       <img className={classes.image} alt="image" src={"http://localhost:8080/"+food.image} />
                       <br/> 
                    </TableCell>
                   <TableCell  >
                   <br/>
                       <Typography variant="h4" align="left" >{food.foodName}</Typography>
                       <Typography variant="h5" align="left" >{food.catName}</Typography>
                       <Typography variant="h6" align="left" >{food.type}</Typography>
                       <Typography align="left" > {food.description}</Typography>
                       <Typography align="left" variant="h5"  >{food.price}</Typography>
                       <Typography  align="right">
                           <Button className={classes.detailsButton}  variant="outlined" 
                           color="primary" align="right" component={NavLink} to={"/"+path+"/edit-food/"+food.id} >
                               Edit </Button>  
                           <Button variant="outlined" color="secondary" onClick={async (e)=>{await setId(food.id); await handleClickOpen()}}  >
                                Delete </Button>
                        </Typography>
                   </TableCell>
                </Table>
            </Paper>
            <br/>
            </div>
             ))}
        </div> 
        <Dialog
        open={open}
       
        keepMounted
        onClose={handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">{"Are You Sure"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
           Do You want to Delete Food Item
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleJustClose} color="primary">
          BACK
          </Button>
          <Button onClick={handleClose} color="primary">
           YES
          </Button>
        </DialogActions>
      </Dialog>
        </div>
    )
}
