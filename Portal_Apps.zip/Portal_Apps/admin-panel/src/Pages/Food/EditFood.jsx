import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { useStyle } from './../../Components/Header/HeaderStyle';
import { Paper, Typography, Box, Button, TextField, MenuItem } from '@material-ui/core';



export default function EditFood() {
    const {id}= useParams()
    const classes = useStyle()
    const [food, setFood] = useState([])
    const [categories, setCetegory] = useState([])
    const[cat ,setCat]= useState([])
    const[type ,setType]= useState([])
    const[image ,setImage]= useState(null)
    const[imagedb ,setImageDb] = useState([])
    const[name ,setName]= useState([])
    const[price ,setPrice]= useState([])
    const[discription ,setDescription]= useState([])

    useEffect(() => {
        getCategorys()
        getFoodData()
      }, [])


      function AddFood(){
          const data = new FormData()
          data.append("foodName",name)
          data.append("price",price)
          data.append("category",cat)
          data.append("type",type)
          data.append("description",discription)
          data.append("image",imagedb)
        //   data.append("imagefile",image)
          


          axios.put("http://localhost:8080/food/update/"+id, data).then((response)=>{
            const result = response.data
            if(result==="success"){
              alert("Food updated sucessfully") 
            }else{
                alert("some error occured") 
                
            }
          })


      }




      function getFoodData()
      {
          axios.get("http://localhost:8080/food/"+id).then((response)=>{
            const result = response.data
            console.log(result)
            if(result.status==="success"){
              setFood(result.data)
              setName(result.data.foodName)
              setDescription(result.data.description)
              setPrice(result.data.price)
              setCat(result.data.catId)
              setType(result.data.type)
              setImageDb(result.data.image)
            }else{
                alert("No data found")
            }
          })
      }
  








    function getCategorys(){
        axios.get("http://localhost:8080/food/category").then((response)=>{
            const result = response.data
           
            if(result.status==="success"){
                setCetegory(result.data)
            }else{
              alert("Error while fetching category data")
            }
          })
    }

    return (
        <div>
            <Paper elevation={15} className={classes.EditPaper}>
            <Typography align="center"  variant="h5" >Edit Food Details</Typography>
                <Box align="center">
                <img className={classes.imageSm} alt="image" src={"http://localhost:8080/"+food.image} /> 
                </Box>
           
             <table>
               <tr>
                  <td>
                    <Box className={classes.editTxt}>
                        Food Name:
                      <input type="email" className="form-control"
                       onChange={(e)=> {
                        setName(e.target.value)
                    }}
                       id="exampleInputEmail1"  placeholder={food.foodName}  aria-describedby="emailHelp"/>
                    </Box>
                  </td>
                  <td>
                  <Box className={classes.editTxt}>
                        Price:
                      <input type="text" className="form-control"
                       onChange={(e)=> {
                        setPrice(e.target.value)
                    }}
                       id="exampleInputEmail1"  placeholder={food.price}  aria-describedby="emailHelp"/>
                    </Box>
                  </td>
              </tr>
              <td colSpan="2">
                  <Box className={classes.editTxt}>
                  Description:
                      <input type="text" className="form-control" 
                       onChange={(e)=> {
                        setDescription(e.target.value)
                    }}
                      id="exampleInputEmail1"   placeholder={food.description} aria-describedby="emailHelp"/>
                    </Box>
              </td>



               <tr>
               <td>
               <TextField
                            id="standard-select-category"
                            className={classes.editTxt}
                            select
                            label="Category"
                            value={cat}
                            onChange={(e)=> {
                                setCat(e.target.value)
                            }}
                            helperText="Please select your category"
                            >{categories.map((option)=>(
                                <MenuItem key={option.id} value={option.id}>
                               {option.categoryName}
                            </MenuItem>
                             ))}
                               
                        </TextField>
                  </td>
                  <td>
                  <TextField
                            id="standard-select-currency"
                            className={classes.editTxt}
                            select
                            label={type}
                            value={type}
                             onChange={(e)=> {
                                setType(e.target.value)
                             }}
                            helperText="Please select your food type"
                            >
                                <MenuItem  value="Veg">
                                    Veg
                                </MenuItem>
                                <MenuItem  value="Non-Veg">
                                   Non-Veg
                                </MenuItem>
                       
                         </TextField>
                  </td>
               </tr>
               <tr>
               <td colSpan="2">
               {/* <TextField 
                        margin="dense" type="email" 
                        className={classes.editTxt} 
                        type="file"
                        onChange={(e)=> {
                            setImage(e.target.files[0])
                        }}
                        accept=".jpeg/.png/.jpg"
                        label="Food Image"/> */}
                  </td>
               </tr>
             </table>
             
<br/>
                        <Typography align="center"  variant="h5" >  
                        <Button align="center" className={classes.editTxt} onClick={AddFood} variant="outlined" color="primary">
                                                    Add 
                                                </Button>
                        </Typography>
                                              
                
            </Paper>
            
        </div>
    )
}
