import React, { useEffect, useState } from 'react'
import { Paper, TextField, Button, Typography, MenuItem, IconButton, Collapse } from '@material-ui/core';
import { useStyle } from './../../Components/Header/HeaderStyle';
import axios from 'axios';
import  Alert  from '@material-ui/lab/Alert';
import  CloseIcon from '@material-ui/icons/Close';


export default function AddFood() {
    const classes = useStyle()
    const [categorys, setCetegory] = useState([])
    const[cat ,setCat]= useState([])
    const[type ,setType]= useState([])
    const[image ,setImage]= useState(null)
    const[name ,setName]= useState([])
    const[price ,setPrice]= useState([])
    const[discription ,setDescription]= useState([])
    const [open, setOpen] =useState(false);
    const [error, setError] =useState(false);
    const[ message, setMessage]= useState([]);
 

    useEffect(() => {
        getCategorys()
      }, [])

      function AddFood(){
        if(name.length===0 && price.length===0
            && type.length===0&& cat.length==0)
        {
            setMessage("Some Fields Are Missing !!")
            setError(true)
        }else if(image === null){
            setMessage("Add Food Image !!")
            setError(true)
        }

          
   
          const data = new FormData()
          data.append("id",0)
          data.append("foodName",name)
          data.append("price",price)
          data.append("category",cat)
          data.append("type",type)
          data.append("description",discription)
          data.append("imagefile",image)
          


          axios.post("http://localhost:8080/food/addfood",data).then((response)=>{
            const result = response.data
            if(result.status==="success"){
               setOpen(true)
            }else{
                setMessage("Error While Adding Food!!")
                 setError(true)
            }
          })


      }



    function getCategorys(){
        axios.get("http://localhost:8080/food/category").then((response)=>{
            const result = response.data
            if(result.status==="success"){
                setCetegory(result.data)
            }else{
                setMessage("Something is wrong , cannot find Categories data")
                setError(true)
            }
          })
    }




    
    return (
        <div><Collapse in={error}>
        <Alert   variant="filled" severity="error"
          action={
            <IconButton
              aria-label="close"
              color="inherit"
              size="small"
              onClick={() => {
                setError(false);
              }}
            >
              <CloseIcon fontSize="inherit" />
            </IconButton>
          }
        >
       {message}
        </Alert>
    </Collapse>
      <Collapse in={open}>
        <Alert   variant="filled"
          action={
            <IconButton
          
              aria-label="close"
              color="inherit"
              size="small"
              onClick={() => {
                setOpen(false);
              }}
            >
              <CloseIcon fontSize="inherit" />
            </IconButton>
          }
        >
        Food Item Added Successfuly .
        </Alert>
    </Collapse>

        <br/>

             <Paper elevation={20} className={classes.EditPaper} >
                <Typography align="center"  variant="h5" >Add Food Item</Typography>
                <br/>

            <div>
            <form  >
                    <div>
                      <TextField 
                           className={classes.editTxt} margin="dense" 
                           onChange={(e)=> {
                            setName(e.target.value)
                        }}
                          label="Food Name" />

                      <TextField 
                          className={classes.editTxt} margin="dense" 
                          onChange={(e)=> {
                            setPrice(e.target.value)
                        }}
                          label="Price" />
                   </div>
                    <div>
                        <TextField 
                        margin="dense" type="email" 
                        className={classes.editTxt} 
                        type="file"
                        onChange={(e)=> {
                            setImage(e.target.files[0])
                        }}
                        accept=".jpeg/.png/.jpg"
                        label="Food Image"/>
                    </div>
                    <div>
                        <TextField margin="dense" type="text"
                        className={classes.editTxt}
                        id="outlined-multiline-static" 
                        onChange={(e)=> {
                            setDescription(e.target.value)
                        }}
                        fullWidth
                        multiline
                         rows={4}
                        label="Description" />
                    </div>
            
                     <div>
                     <TextField
                            id="standard-select-currency"
                            className={classes.editTxt}
                            select
                            label="Category"
                            value={cat}
                            onChange={(e)=> {
                                setCat(e.target.value)
                            }}
                            helperText="Please select your category"
                            >{categorys.map((option)=>(
                                <MenuItem key={option.id} value={option.id}>
                               {option.categoryName}
                            </MenuItem>
                             ))}
                               
                        </TextField>


                        <TextField
                            id="standard-select-currency"
                            className={classes.editTxt}
                            select
                            label="Type"
                            value={type}
                            onChange={(e)=> {
                                setType(e.target.value)
                            }}
                            helperText="Please select your food type"
                            >
                                <MenuItem  value="Veg">
                                    Veg
                                </MenuItem>
                                <MenuItem  value="Non-Veg">
                                   Non-Veg
                                </MenuItem>
                       
                         </TextField>
                    </div>
                    <div>
                        
                    </div>
                   
                    </form>
                <br/>
          
            </div>
            <br/>
            <br/>
            <Button onClick={AddFood} variant="outlined" color="primary">
             Add 
        </Button>
        </Paper>

            
        </div>
    )
}
