import React, { useEffect, useState } from 'react'
import { Paper, Box,  Typography, Button, Menu, MenuItem, Collapse, IconButton } from '@material-ui/core';
import { useStyle } from '../../Components/Header/HeaderStyle';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios'
import Alert from '@material-ui/lab/Alert';
import CloseIcon from '@material-ui/icons/Close';


export default function EditUser() {
  
 
   const {id}= useParams()
   const history= useHistory()
    const classes = useStyle()
    const [open, setOpen] =useState(false);
    const [employee, setEmployee] = useState([])
    const [firstName, setFirstName] = useState()
    const [lastName, setLastName] = useState()
    const [email, setEmail] = useState()
    const [password, setPassword] = useState()
    const [phone, setPhone] = useState()
    const [address, setAddress] = useState()
    const [role, setRole] = useState()
   


    useEffect(() => {
      getEmployee()
    },[])
  
  
  
    function getEmployee(){
      axios.get('http://localhost:8080/user/'+id).then((response)=>{
        const result = response.data
        if(result.status==="success"){
          setEmployee(result.data)
          setFirstName(result.data.firstName)
          setLastName(result.data.lastName)
          setEmail(result.data.email)
          setPassword(result.data.password)
          setPhone(result.data.phone)
          setAddress(result.data.address)
          
        }else{
          alert("No data found")
        }
      })
  }
    
   

      function updateEmployee(){
      const newData = new FormData()
      newData.append('id', employee.id )
      newData.append('firstName', firstName )
      newData.append('lastName', lastName )
      newData.append('email', email )
      newData.append('password', password )
      newData.append('phone', phone )
      newData.append('address', address )
    

     

       axios.put('http://localhost:8080/user/update/'+id,newData).then((response)=>{
         const result = response.data
         console.log(result)
             if(result==="success"){
              setOpen(true)
           }else{
               alert("No data found")
             }
        })
      }

     
      

      
    return (
        <Box>
            <Collapse in={open}>
                <Alert   variant="filled"
                  action={
                    <IconButton
                  
                      aria-label="close"
                      color="inherit"
                      size="small"
                      onClick={() => {
                        setOpen(false);
                      }}
                    >
                      <CloseIcon fontSize="inherit" />
                    </IconButton>
                  }
                >
                User Updated Successfuly .
                </Alert>
            </Collapse>


            <Paper elevation={15} className={classes.EditPaper}>
            <Typography align="center"  variant="h5" >Edit User</Typography>
             <table>
               <tr>
                  <td>
                    <Box className={classes.editTxt}>
                        First Name:
                      <input type="email" className="form-control"
                      onChange={(e) => {
                        setFirstName(e.target.value)
                      }} 
                       id="exampleInputEmail1"  placeholder={employee.firstName} aria-describedby="emailHelp"/>
                    </Box>
                  </td>
                  <td>
                  <Box className={classes.editTxt}>
                        Last Name:
                      <input type="text" className="form-control"
                       onChange={(e) => {
                        setLastName(e.target.value)
                      }} 
                       id="exampleInputEmail1"  placeholder={employee.lastName} aria-describedby="emailHelp"/>
                    </Box>
                  </td>
              </tr>
              <td colSpan="2">
                  <Box className={classes.editTxt}>
                        Email:
                      <input type="text" className="form-control" 
                       onChange={(e) => {
                        setEmail(e.target.value)
                      }} 
                      id="exampleInputEmail1"  placeholder={employee.email} aria-describedby="emailHelp"/>
                    </Box>
              </td>



               <tr>
               <td>
                    <Box className={classes.editTxt}>
                        Password:
                      <input type="password" className="form-control"
                       onChange={(e) => {
                        setPassword(e.target.value)
                      }} 
                       id="exampleInputEmail1"  placeholder="Enter Password" aria-describedby="emailHelp"/>
                    </Box>
                  </td>
                  <td>
                  <Box className={classes.editTxt}>
                        phone:
                      <input type="number" className="form-control"
                       onChange={(e) => {
                        setPhone(e.target.value)
                      }} 
                       id="exampleInputEmail1"  placeholder={employee.phone} aria-describedby="emailHelp"/>
                    </Box>
                  </td>
               </tr>
               <tr>
               <td colSpan="2">
                    <Box className={classes.editTxt}>
                        Address:
                      <input type="yext" className="form-control"  onChange={(e) => {
                          setAddress(e.target.value)
                        }} 
                       id="exampleInputEmail1"  placeholder={employee.address} aria-describedby="emailHelp"/>
                    </Box>
                  </td>
               </tr>
             </table>
            
<br/>
<br/>
                        <Typography align="center"  variant="h5" >  
                        <Button align="center" className={classes.editTxt} onClick={updateEmployee} variant="outlined" color="primary">
                                                    Add 
                                                </Button>
                        </Typography>
                                              
                
            </Paper>
            
        </Box>

    )
}
