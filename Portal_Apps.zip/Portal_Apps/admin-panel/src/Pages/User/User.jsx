import { React,useState, useEffect } from 'react'
import  axios from 'axios'
import { Box, Table, TableBody, TableCell, TableHead, TableRow,Typography } from '@material-ui/core'
import Paper from '@material-ui/core/Paper';

import {  NavLink } from 'react-router-dom';
import { useStyle } from '../../Components/Header/HeaderStyle';
import  Cookies from 'universal-cookie';

function User(url) {
  const cookies = new Cookies()
  const path = cookies.get("role")
  const urlptn= url.url
    const classes = useStyle();
    const [users, setUsers] = useState([])
    useEffect(() => {
      
      getUser()
    }, [])

    function getUser(){
        axios.get("http://localhost:8080/user").then((response)=>{
          const result = response.data
          if(result.status==="success"){
            setUsers(result.data)
           
          }else{
              alert("something went wrong")
          }

        })
    }




    return (
        <Box>
      
    
        <Paper elevation={15} >
        <Table className={classes.table} aria-label="customized table">
          <TableHead className={classes.tableHead}>
            <TableRow>
              <TableCell align="left" ><Typography variant="h6" >Id</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Name</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Email</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Phone</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Address</Typography></TableCell>
              <TableCell align="left"><Typography variant="h6">Date</Typography></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user,i) => (
                
                <TableRow key={i} className={classes.link} component={NavLink} to={'/'+path+'/user/'+ user.id} >
                    <TableCell align="left" component="th" scope="row">
                    <Typography >{user.id}</Typography>  
                       </TableCell>
                    <TableCell align="left">
                    <Typography >{user.firstName} {user.lastName}</Typography>  </TableCell>
                    <TableCell align="left"><Typography >{user.email}</Typography>  </TableCell>
                    <TableCell align="left"><Typography >{user.phone}</Typography>  </TableCell>
                    <TableCell align="left"><Typography >{user.address}</Typography>  </TableCell>
                    <TableCell align="left"><Typography >{user.timeStamp}</Typography>  </TableCell>
                </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
      </Box>
        
    )
}

export default User
