
import React, { useEffect, useState  } from 'react'
import { useHistory, NavLink } from 'react-router-dom';
import axios from 'axios'

import {  useParams } from 'react-router';
import { Box, Paper, Typography, Table, TableCell, TableRow, TableBody, Button } from '@material-ui/core';
import { useStyle } from './../../Components/Header/HeaderStyle';
import  Cookies  from 'universal-cookie';



export default function UserData() {
    const history= useHistory()
    const classes = useStyle();
    const {id}= useParams();
    const [user, setUser] = useState([])
    const cookies = new Cookies()
    const path = cookies.get("role")


    function deleteUser(){
        axios.delete('http://localhost:8080/user/delete/'+id).then((response)=>{
          const result = response.data
          console.log(result)
          if(result.status!==""){
           history.push('/user')
          }else{
            history.push('/emp')
            alert("Error deleting emloyee")
          }
        })
    }

    useEffect(() => {
        getUser()
      },[])


    function getUser(){
        axios.get('http://localhost:8080/user/'+id).then((response)=>{
          const result = response.data
          if(result.status==="success"){
            setUser(result.data)
          }else{
            alert("No data found")
          }
        })
    }
   
    

    return (
        <Box>
        <Paper className={classes.detailsBoxContainer} elevation={15}  >
            <Table className={classes.detailsbox} aria-label="caption table">
                <TableBody>
                <TableRow >
                <TableCell align="Left"> <Typography variant="h6">Id :</Typography></TableCell>
                <TableCell align="Left"> <Typography variant="h6">{user.id}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">First Name :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.firstName}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Last Name : </Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.lastName}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Email :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.email}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Password :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.password}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Phone :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.phone}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Address :</Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.address}</Typography></TableCell>
                </TableRow>
                <TableRow >
                    <TableCell align="Left"> <Typography variant="h6">Joining Date :  </Typography></TableCell>
                <   TableCell align="Left"> <Typography variant="h6">{user.timeStamp}</Typography></TableCell>
                </TableRow>
            </TableBody>
        </Table>
    </Paper>
    <br/>
    <br/>
         <Box className={classes.detailsButton}>
            <Button onClick={deleteUser}  className={classes.button} variant="contained" color="secondary">
            Delete
            </Button>

            <Button className={classes.button} variant="contained" component={NavLink} to={'/'+path+'/edit-user/'+user.id} color="primary">
                Edit
            </Button>
        </Box>
</Box>
       
    )
}

